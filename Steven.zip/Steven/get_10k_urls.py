import pandas as pd
from sec_api import QueryApi
import tqdm


api_key = ''
queryApi = QueryApi(api_key=api_key)

def standardize_filing_url(url):
  return url.replace('ix?doc=/', '')


def get_10K_metadata(start_year = 2016, end_year = 2023):
  frames = []

  for year in tqdm.tqdm(range(start_year, end_year + 1)):
    number_of_objects_downloaded = 0

    for month in tqdm.tqdm(range(1, 13)):
      padded_month = str(month).zfill(2) # "1" -> "01"
      date_range_filter = f'filedAt:[{year}-{padded_month}-01 TO {year}-{padded_month}-31]'
      form_type_filter  = f'formType:"10-K" AND NOT formType:("10-K/A", NT)'
      lucene_query = date_range_filter + ' AND ' + form_type_filter

      query_from = 0
      query_size = 200

      while True:
        query = {
          "query": lucene_query,
          "from": query_from,
          "size": query_size,
          "sort": [{ "filedAt": { "order": "desc" } }]
        }

        response = queryApi.get_filings(query)
        filings = response['filings']

        if len(filings) == 0:
          break
        else:
          query_from += query_size

        metadata = list(map(lambda f: {'ticker': f['ticker'],
                                       'cik': f['cik'],
                                       'formType': f['formType'],
                                       'filedAt': f['filedAt'],
                                       'filingUrl': f['linkToFilingDetails']
                                      }, filings))

        df = pd.DataFrame.from_records(metadata)
        # remove all entries without a ticker symbol
        df = df[df['ticker'].str.len() > 0]
        df['filingUrl'] = df['filingUrl'].apply(standardize_filing_url)
        frames.append(df)
        number_of_objects_downloaded += len(df)

    print(f'✅ Downloaded {number_of_objects_downloaded} metadata objects for year {year}')

  result = pd.concat(frames)

  print(f'✅ Download completed. Metadata downloaded for {len(result)} filings.')

  return result

metadata_10K = get_10K_metadata(start_year=2016, end_year=2023)
metadata_10K.to_csv(r'C:\MasterUlm\Semester_2\Projekt_Data_Science\metadata_10_k_no_ticker.csv', index=False)
