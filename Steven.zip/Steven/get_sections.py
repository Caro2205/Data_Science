import pandas as pd
import requests
import concurrent.futures
import tqdm

df = pd.read_csv(r'C:\MasterUlm\Semester_2\Projekt_Data_Science\metadata_10_k_no_ticker.csv')
print(df.columns)

SECTIONS = ["1", "1A", "1B", "1C", "2", "3", "4", "5", "6", "7", 
            "7A", "8", "9", "9A", "9B", "10", "11", "12", "13", 
            "14", "15"]

def fetch_sections_10k(row, token):
    row_dict = row.to_dict()

    filing_url = row_dict.get('filingUrl', '')

    for sec in SECTIONS:
        api_url = "https://api.sec-api.io/extractor"
        params = {
            "url": filing_url,
            "item": sec,
            "type": "text",
            "token": token
        }
        try:
            resp = requests.get(api_url, params=params, timeout=10)
            if resp.status_code == 200:
                section_text = resp.text
            else:
                section_text = ""
        except Exception as e:
            section_text = ""

        row_dict[f"section_{sec}"] = section_text

    return row_dict

def expand_df_with_sections_concurrently(df, token, max_workers=5):
    results = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_index = {
            executor.submit(fetch_sections_10k, row, token): index
            for index, row in df.iterrows()
        }
        for future in tqdm.tqdm(concurrent.futures.as_completed(future_to_index)):
            index = future_to_index[future]
            try:
                result_dict = future.result()
                results.append(result_dict)
            except Exception as e:

                print(f"Row {index} failed with error: {e}")

    expanded_df = pd.DataFrame(results)
    return expanded_df


api_key = 'b6bb6230e398fc78013fed42e2a0d04627b315a5e82d8e80f2d4018b88417d90'
new_df = expand_df_with_sections_concurrently(df, api_key)
new_df.to_csv("expanded_10k_data.csv", index=False)


