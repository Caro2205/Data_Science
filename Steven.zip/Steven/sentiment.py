from transformers import AutoTokenizer, AutoModelForSequenceClassification
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
import pyarrow as pa
import tqdm
import torch
import argparse
import json


def concatenate_complexity_10k():
    complexity_path = Path('/home/steven/Uni/semester2/Data_Science/data/complexity_scores_final.csv')
    preprocessed_path = Path('/home/steven/Uni/semester2/Data_Science/data/preprocessed_stage_one.parquet')

    complexity_df = pd.read_csv(complexity_path)
    preprocessed_df = pd.read_parquet(preprocessed_path)

    complexity_df['filingUrl'] = complexity_df['file_name']
    merged_df = pd.merge(complexity_df, preprocessed_df, on='filingUrl', how='inner')
    merged_df.to_parquet('/home/steven/Uni/semester2/Data_Science/data/raw_regrssion_df.parquet', compression='snappy', index=False)


def get_sentiment_df(config):
    model_dir = Path(config['model_dir'])
    tokenizer = AutoTokenizer.from_pretrained(config['tokenizer'])
    model = AutoModelForSequenceClassification.from_pretrained(model_dir)
    model.to("cuda")
    model.eval()

    data_path = Path('/home/steven/Uni/semester2/Data_Science/data/raw_regrssion_df.parquet')

    items = ['section_1', 'section_1A', 'section_1B', 'section_2',
             'section_3', 'section_4', 'section_5', 'section_6', 'section_7',
             'section_7A', 'section_8', 'section_9', 'section_9A', 'section_9B',
             'section_10', 'section_11', 'section_12', 'section_13', 'section_14',
             'section_15']
    data = pq.ParquetFile(data_path)
    output_path = config['output_path']

    def sentiment(batch_texts):
        with torch.no_grad():
            inputs = tokenizer(batch_texts, return_tensors="pt", padding=True, truncation=True, 
                               max_length=config['max_length']).to("cuda")
            outputs = model(**inputs)
            return torch.argmax(outputs.logits, dim=1).tolist()

    batches = []
    schema = pa.schema([(col, pa.int64()) for col in items] + 
                       [('filingUrl', pa.string()), ('filing_date', pa.int64()), ('file_name', pa.string()), 
                        ('cik', pa.int64()), ('complexity_score', pa.float64())])
    
    for batch in tqdm.tqdm(data.iter_batches(batch_size=8), desc="Processing Batches"):
        batch_df = batch.to_pandas()

        for item in items:
            mask = batch_df[item].notna()
            batch_texts = batch_df.loc[mask, item].tolist()
            if batch_texts:
                batch_df.loc[mask, item] = sentiment(batch_texts)
        batches.append(pa.Table.from_pandas(batch_df, schema=schema))

    pq.write_table(pa.concat_tables(batches), output_path, compression='snappy', use_dictionary=True)



parser = argparse.ArgumentParser(description="Running sentiment analysis")
parser.add_argument("--config", type=str, help="Path to the config file of the Bert model")
args = parser.parse_args()
config_path = args.config
config = json.load(open(config_path))
torch.set_float32_matmul_precision('high')
get_sentiment_df(config)