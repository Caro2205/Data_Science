import pandas as pd
import re
from pathlib import Path
import html
import tqdm
import pyarrow.parquet as pq
import pyarrow as pa

def preprocess_stage_one():
    def decode_html(text):
        return re.sub(r"\s+", " ", text).strip()

    raw_path = Path('/home/steven/Uni/semester2/Data_Science/data/raw_text.parquet')
    output_path = Path('/home/steven/Uni/semester2/Data_Science/data/preprocessed_stage_one.parquet')

    sections = [
        'section_1', 'section_1A', 'section_1B', 'section_1C', 'section_2', 'section_3',
        'section_4', 'section_5', 'section_6', 'section_7', 'section_7A', 'section_8',
        'section_9', 'section_9A', 'section_9B', 'section_10', 'section_11', 'section_12',
        'section_13', 'section_14', 'section_15', 'filingUrl'
    ]

    schema = pa.schema([(col, pa.string()) for col in sections])

    regex_patterns = {
        "ascii_encoded": re.compile(r"<TYPE>.*?(GRAPHIC|ZIP|EXCEL|JSON|PDF).*?", re.DOTALL),
        "tables": re.compile(r"<TABLE>.*?</TABLE>", re.DOTALL),
        "xml": re.compile(r"<XML>.*?</XML>", re.DOTALL),
        "xbrl": re.compile(r"<XBRL>.*?</XBRL>", re.DOTALL),
        "sec_footer": re.compile(r"-----END PRIVACY-ENHANCED MESSAGE-----.*", re.DOTALL),
        "html_tags": re.compile(r"</?(DIV|TR|TD|FONT)[^>]*>", re.DOTALL),
        "markup_tags": re.compile(r"<[^>]+>", re.DOTALL),
        "exhibit_tagging": re.compile(r"<EXHIBIT>(.*?)</EXHIBIT>", re.DOTALL),
        "extra_line_breaks": re.compile(r"\n\s*\n", re.DOTALL),
    }

    html_replacements = {
        '&NBSP;': ' ',
        '&#160;': ' ',
        '&#38;': '&',
        '&AMP;': '&',
    }
    remove_entities = {f'&#{entity};': '' for entity in [
        131, 133, 134, 135, 136, 137, 138, 139, 140, 149, 153, 154, 155, 156, 159, 160, 
        161, 162, 163, 164, 165, 167, 168, 169, 170, 172, 174, 175, 176, 177, 178, 179, 
        180, 181, 183, 185, 186, 187, 188, 189, 190, 191
    ]}
    html_replacements.update(remove_entities)

    parquet_file = pq.ParquetFile(raw_path)
    output_batches = []

    for batch in tqdm.tqdm(parquet_file.iter_batches(batch_size=500), desc="Processing Batches"):
        batch_df = batch.to_pandas()  
        for section in batch_df.columns:
            batch_df[section] = batch_df[section].astype(pd.StringDtype())

            for pattern in regex_patterns.values():
                batch_df[section] = batch_df[section].str.replace(pattern, "", regex=True)

            batch_df[section] = batch_df[section].replace(html_replacements, regex=True)

            batch_df[section] = batch_df[section].map(decode_html, na_action='ignore')


        output_batches.append(pa.Table.from_pandas(batch_df, schema=schema))

    pq.write_table(pa.concat_tables(output_batches), output_path, compression='snappy', use_dictionary=True)

    print(f"Preprocessed data saved to: {output_path}")



df = pd.read_parquet('data/ModernBERT_final.parquet')
print(len(df))
