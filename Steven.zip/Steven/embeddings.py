from transformers import AutoTokenizer, AutoModel
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
import pyarrow as pa
import tqdm
import torch


def extract_embeddings_from_model(model_name: str, tokenizer_name: str):
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
    model = AutoModel.from_pretrained(model_name)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    model.eval()

    data_path = Path('/home/steven/Uni/semester2/Data_Science/data/raw_regrssion_df.parquet')
    output_path = Path(f'/home/steven/Uni/semester2/Data_Science/data/{model_name.replace("/", "_")}_embeddings.parquet')

    text_columns = ['section_1', 'section_1A', 'section_1B', 'section_2',
                    'section_3', 'section_4', 'section_5', 'section_6', 'section_7',
                    'section_7A', 'section_8', 'section_9', 'section_9A', 'section_9B',
                    'section_10', 'section_11', 'section_12', 'section_13', 'section_14',
                    'section_15']

    data = pq.ParquetFile(data_path)

    def get_embeddings(batch_texts):
        with torch.no_grad():
            inputs = tokenizer(batch_texts, return_tensors="pt", padding=True, truncation=True).to(device)
            outputs = model(**inputs)
            cls_token =  outputs.last_hidden_state[:, 0, :].cpu()  
            return cls_token

    embedding_dim = 768  # adjust if using a different model
    batches = []

    for batch in tqdm.tqdm(data.iter_batches(batch_size=8), desc=f"Embedding with {model_name}"):
        batch_df = batch.to_pandas()

        for column in text_columns:
            mask = batch_df[column].notna()
            texts = batch_df.loc[mask, column].tolist()

            if texts:
                embeddings = get_embeddings(texts)  # shape [N_valid_rows, 768]
                embedding_array = embeddings.numpy()

                embedding_cols = [f"{column}_emb_{i}" for i in range(embedding_array.shape[1])]
                embedding_df = pd.DataFrame(embedding_array, index=batch_df[mask].index, columns=embedding_cols)
                # Drop the original text column
                batch_df = batch_df.drop(columns=[column])

                # Join the expanded embedding columns
                batch_df = batch_df.join(embedding_df)

        batches.append(pa.Table.from_pandas(batch_df, preserve_index=False))


    pq.write_table(pa.concat_tables(batches), output_path, compression='snappy', use_dictionary=True)
    print(f"Saved embeddings to: {output_path}")


if __name__ == "__main__":
    torch.set_float32_matmul_precision('high')
    model_name = 'HYdsl/FiLM-SEC'
    tokenizer_name = 'roberta-base'  # or model_name if model includes tokenizer
    extract_embeddings_from_model(model_name, tokenizer_name)
