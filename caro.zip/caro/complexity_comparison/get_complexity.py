import pandas as pd

with open("complexity_words.txt", "r") as cw_file:
    complexity_words = set(cw_file.read().splitlines())

# convert to lower case
complexity_words = {word.lower() for word in complexity_words}

def calculate_complexity(content, complexity_words):
    words = content.lower().split()
    total_words = len(words)
    complexity_count = sum(1 for word in words if word in complexity_words)
    complexity_score = (complexity_count / total_words) * 100 if total_words > 0 else 0
    return complexity_score

with open("comparison/in_steven.txt", "r") as delete_file:
    delete_content = delete_file.read()
delete_complexity_score = calculate_complexity(delete_content, complexity_words)

with open("comparison/in_original.txt", "r") as insert_file:
    insert_content = insert_file.read()
insert_complexity_score = calculate_complexity(insert_content, complexity_words)

complexity_scores = {
    "n_steven.txt": {"complexity_score": delete_complexity_score},
    "in_original.txt": {"complexity_score": insert_complexity_score}
}
complexity_scores["n_steven.txt"].update({
    "complexity_word_count": sum(1 for word in delete_content.lower().split() if word in complexity_words),
    "total_word_count": len(delete_content.lower().split())
})
complexity_scores["in_original.txt"].update({
    "complexity_word_count": sum(1 for word in insert_content.lower().split() if word in complexity_words),
    "total_word_count": len(insert_content.lower().split())
})

complexity_df = pd.DataFrame.from_dict(complexity_scores, orient='index')
complexity_df.to_csv("comparison/complexity_scores.csv", index_label="file_name")
