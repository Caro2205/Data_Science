import pandas as pd

complexity_scores = pd.read_csv('/home/caro/DS_complexity/complexity_scores_new_reformatted.csv')

final_data = pd.read_parquet('/home/caro/DS_complexity/data/final_data_reformatted.parquet')
print(final_data.head())

final_data['CIK'] = final_data['CIK'].astype('Int64')
complexity_scores['filing_date'] = complexity_scores['filing_date'].astype(str)
final_data['Filing Date'] = final_data['Filing Date'].astype(str)

merged_data = pd.merge(complexity_scores, final_data, how='inner', left_on=['cik', 'filing_date'], right_on=['CIK', 'Filing Date'])

filtered_data = merged_data[['file_name', 'complexity_score', 'cik', 'filing_date']]

filtered_data.to_csv('/home/caro/DS_complexity/complexity_scores_final.csv', index=False)