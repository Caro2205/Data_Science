import pandas as pd
import numpy as np

# config
model_name = "finbert_final"  # or "film_sec_final", modernbert_final, film_final, finbert_final
model_clear_name = model_name.replace("_final", "")
windows = [
    ("1_day_before_after", "1d"),
    ("30", "30d"),
    ("60", "60d"),
    ("90", "90d")
]
base_path = "" 


# read and combine data
dfs = {}
for win_file, win_label in windows:
    file_path = f"{model_name}_{win_file}.csv" # {base_path}/
    df = pd.read_csv(file_path)
    dfs[win_label] = df

#items = sorted(items)  # Use custom_sort_key for sorting
# create item list
items = dfs[windows[0][1]].loc[dfs[windows[0][1]].Complexity == "Low", "Variable"].tolist() # without removing 0.0/nan rows
print(items)

def format_cell(coef, se):
    return r"\begin{tabular}{@{}c@{}}" + f"{coef} \\\\ ({se})" + r"\end{tabular}"

latex_lines = [
    r"\begin{table}[ht]",
    r"\small",
    r"\caption{Linear regression results of relating CAR to the sentiment categories obtained by " +str(model_clear_name)+ "}"
    r"\parbox{\textwidth}{CAR is the Cumulative Abnormal Returns calculated with respect to different time windows: CAR[-1, 1], CAR[0, 30], CAR[0, 60], CAR[0, 90]. As independent variables, we use dummies of the positive and negative sentiment categories of each item of the 10-K reports. As controls, we add the Log of S\&P500, Total Assets and the first digit of the SIC code of the firm also as a dummy variables. The data is additionally split by the firms complexity into low and high complexity. Significance levels are denoted by stars: * for $p < 0.1$, ** for $p < 0.05$, and *** for $p < 0.01$.}",
    r"\centering",
    r"\resizebox{\textwidth}{!}{",
    r"\begin{tabular}{l *{8}{c}}",
    r"\toprule",
    r"& \multicolumn{2}{c}{\textbf{CAR[-1,1]}} & \multicolumn{2}{c}{\textbf{CAR[0,30]}} & \multicolumn{2}{c}{\textbf{CAR[0,60]}} & \multicolumn{2}{c}{\textbf{CAR[0,90]}} \\",
    r"\cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7} \cmidrule(lr){8-9}",
    r"\textbf{Item} & \textbf{Low} & \textbf{High} & \textbf{Low} & \textbf{High} & \textbf{Low} & \textbf{High} & \textbf{Low} & \textbf{High} \\",
    r"\midrule"
]

for item in items:
    row = [f'${item.replace("_", "-")}$']
    for win_file, win_label in windows:
        df = dfs[win_label]
        # Low
        subdf_low = df[(df.Variable == item) & (df.Complexity == "Low")]
        coef_low = subdf_low["Coef"].values[0]
        se_low = subdf_low["SE"].values[0]
        cell_low = format_cell(coef_low, se_low)
        # High
        subdf_high = df[(df.Variable == item) & (df.Complexity == "High")]
        coef_high = subdf_high["Coef"].values[0]
        se_high = subdf_high["SE"].values[0]
        cell_high = format_cell(coef_high, se_high)

        row.extend([cell_low, cell_high])
    latex_lines.append(" & ".join(row) + r" \\")
latex_lines += [
    r"\bottomrule",
    r"\end{tabular}}",
    r"The number observed 10-K reports is 13638."
    r"\label{tab:bigtable}",
    r"\end{table}"
]

output_path = f"{model_name}_summary_latex_table.tex" # {base_path}/
with open(output_path, "w") as f:
    f.write("\n".join(latex_lines))

print(f"LaTeX table saved to {output_path}")
