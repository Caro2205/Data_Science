import pandas as pd
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
import numpy as np
import json
import seaborn as sns
import datetime
import matplotlib.pyplot as plt

def log_to_file(filename, message):
    safe_filename = filename.replace(":", "-").replace(" ", "_")
    with open(f'{safe_filename}', "a") as file: 
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        file.write(f"[{timestamp}] {message}\n")

# data paths
file_path = '/home/caro/DS_complexity/final_regression/data/CAR_data.csv'
film_final_path = '/home/caro/DS_complexity/final_regression/data/FiLM_final.parquet'
film_sec_final_path = '/home/caro/DS_complexity/final_regression/data/FiLM_sec_final.parquet'
modernbert_final_path = '/home/caro/DS_complexity/final_regression/data/ModernBERT_final.parquet'
finbert_final_path = '/home/caro/DS_complexity/final_regression/data/finbert_final.parquet'
complexity_scores_path = '/home/caro/DS_complexity/final_regression/data/complexity_scores_final.csv'

# reading in data
car_data = pd.read_csv(file_path)
car_data['Filing Date'] = pd.to_datetime(car_data['Filing Date'], format='%d/%m/%Y').dt.strftime('%Y%m%d')
car_data = pd.DataFrame(car_data)

print("Column names in car_data:")
print(car_data.columns)
#print(car_data.head())

film_final = pd.read_parquet(film_final_path)
film_final = pd.DataFrame(film_final)
#print(film_final.head())

film_sec_final = pd.read_parquet(film_sec_final_path)
film_sec_final = pd.DataFrame(film_sec_final)
#print(film_sec_final.head())

modernbert_final = pd.read_parquet(modernbert_final_path)
modernbert_final = pd.DataFrame(modernbert_final)
#print(modernbert_final.head())

finbert_final = pd.read_parquet(finbert_final_path)
finbert_final = pd.DataFrame(finbert_final)
#print(finbert_final.head())

# SET MODEL TO BE USED HERE
FINAL_MODEL = 'film_sec_final'  # Options: 'film_final', 'film_sec_final', 'modernbert_final', 'finbert_final'
TIME_WINDOW = '1_day_before_after'  # Options: '30', '60', '90', '1_day_before_after'

# Remove all data where time window is '250' 
car_data = car_data[~car_data['Window'].isin(['250'])]

final_model_df = {
    'film_final': film_final,
    'film_sec_final': film_sec_final,
    'modernbert_final': modernbert_final,
    'finbert_final': finbert_final
}[FINAL_MODEL]

#final_model_df['filing_date'] = final_model_df['filing_date'].astype('object')
car_data['Filing Date'] = car_data['Filing Date'].astype('int64')
data_all_windows = pd.merge(final_model_df, car_data, left_on=['filing_date', 'cik'], right_on=['Filing Date', 'CIK'], how='inner')

#  Print the length of all used dataframes
'''print(f"Length of car_data: {len(car_data)}")
print(f"Length of film_final: {len(film_final)}")
print(f"Length of film_sec_final: {len(film_sec_final)}")
print(f"Length of modernbert_final: {len(modernbert_final)}")
print(f"Length of finbert_final: {len(finbert_final)}")
print(f"Length of final_model_df: {len(final_model_df)}")
print(f"Length of merged data: {len(data_all_windows)}")'''

# Print the number of NaN values in each section for all dataframes
sections = ['section_1', 'section_1A', 'section_1B', 'section_2', 'section_3',
            'section_4', 'section_5', 'section_6', 'section_7', 'section_7A',
            'section_8', 'section_9', 'section_9A', 'section_9B', 'section_10',
            'section_11', 'section_12', 'section_13', 'section_14', 'section_15']


# Print the number of NaN values in each section for all dataframes
'''print("NaN values in car_data:")
print(car_data['CAR'].isna().sum())

print("\nNaN values per section in film_final:")
print(film_final[sections].isna().sum())

print("\nNaN values per section in film_sec_final:")
print(film_sec_final[sections].isna().sum())

print("\nNaN values per section in modernbert_final:")
print(modernbert_final[sections].isna().sum())

print("\nNaN values per section in finbert_final:")
print(finbert_final[sections].isna().sum())

print("\nNaN values per section in merged data (data_all_windows):")
print(data_all_windows[sections].isna().sum())'''

# Map values in sections from {0, 1, 2} to {-1, 0, 1}
data_all_windows[sections] = data_all_windows[sections].replace({0: -1, 1: 0, 2: 1})

# Replace NaN values in the specified sections with 1 in the merged data
data_all_windows[sections] = data_all_windows[sections].fillna(0)

# Print the frequency of each unique CIK in data_all_windows
'''print("\nFrequency of each unique CIK in data_all_windows:")
print(data_all_windows['cik'].value_counts())
cik_frequency = data_all_windows['cik'].value_counts().to_dict()
output_path = '/home/caro/DS_complexity/final_regression/data/cik_frequency.json' 

with open(output_path, 'w') as json_file:
    json.dump(cik_frequency, json_file)

print(f"CIK frequency data saved to {output_path}") '''

# Print the frequency of each value in each section
#for section in sections:
#    print(f"\nValue counts for {section}:")
#    print((data_all_windows[section].value_counts() / 3).round().astype(int))

# add dummy variables to the data
for section in sections:
    data_all_windows[section + "_neg"] = (data_all_windows[section] == -1).astype(int)

for section in sections:
    data_all_windows[section + "_pos"] = (data_all_windows[section] == 1).astype(int)

# Add dummies for the first digit of the SIC code
data_all_windows['sic_category'] = data_all_windows['sic_code'].astype(str).str[0]
sic_dummies = pd.get_dummies(data_all_windows['sic_category'], prefix='sic', drop_first=False).astype(int)

# Add the SIC dummies to the main dataframe
data_all_windows = pd.concat([data_all_windows, sic_dummies], axis=1)

print(f"Data length before removing sic_dummies with value 6: {len(data_all_windows)}")
# Remove rows where sic_dummies column 'sic_6' is 1
if 'sic_6' in sic_dummies.columns:
    data_all_windows = data_all_windows[sic_dummies['sic_6'] != 1]
print(f"Data length after removing sic_dummies with value 6: {len(data_all_windows)}")

############################################################################################ complexity splitting

data = data_all_windows[data_all_windows['Window'] == TIME_WINDOW]
#data = data_all_windows.copy()

# Print the initial count of data
print(f"Initial data count: {len(data)}")

# Remove rows where 'Total Assets' is 0
data = data[data['Total Assets'] != 0]

# Save the filtered data to a CSV file named after the FINAL_MODEL
'''final_model_csv_path = f'/home/caro/DS_complexity/final_regression/data/{FINAL_MODEL}.csv'
data.to_csv(final_model_csv_path, index=False)
print(f"Filtered data saved to {final_model_csv_path}")'''

print(f"Data count after removing rows with 'Total Assets' equal to 0: {len(data)}")

print(data.head())
print(data.columns)

complexity_threshold = data['complexity_score'].median()

##### split firms in high and low complexity
# Calculate the average complexity score for each firm
firm_complexity_avg = data.groupby('cik')['complexity_score'].median()

# Identify firms with low and high complexity based on the threshold
low_complexity_firms = firm_complexity_avg[firm_complexity_avg <= complexity_threshold].index
high_complexity_firms = firm_complexity_avg[firm_complexity_avg > complexity_threshold].index

# Split the data based on the firm's average complexity
low_complexity = data[data['cik'].isin(low_complexity_firms)]
high_complexity = data[data['cik'].isin(high_complexity_firms)]
print(f'Number of low complexity firms', len(low_complexity_firms))
print(f'Number of low complexity data: ', len(low_complexity))
print(f'Number of high complexity firms', len(high_complexity_firms))
print(f'Number of high complexity data: ', len(high_complexity))

'''
# Save complexity scores with CIK, filing date, and complexity level
complexity_split = pd.concat([
    low_complexity[['cik', 'filing_date', 'complexity_score']].assign(complexity='low'),
    high_complexity[['cik', 'filing_date', 'complexity_score']].assign(complexity='high')
])

# Save to CSV
complexity_split_path = '/home/caro/DS_complexity/final_regression/data/complexity_split.csv'
complexity_split.to_csv(complexity_split_path, index=False)
print(f"Complexity split data saved to {complexity_split_path}")
'''

################ create table of counts of sections in low and high complexity data
counts_data = []

for section in sections:
    low_counts = low_complexity[section].value_counts().reindex([-1, 0, 1], fill_value=0)
    high_counts = high_complexity[section].value_counts().reindex([-1, 0, 1], fill_value=0)
    
    counts_data.append({
        'Section': section,
        'Low_Neg': low_counts[-1],
        'Low_Neutral': low_counts[0],
        'Low_Pos': low_counts[1],
        'High_Neg': high_counts[-1],
        'High_Neutral': high_counts[0],
        'High_Pos': high_counts[1]
    })

counts_df = pd.DataFrame(counts_data)

counts_df['Section'] = counts_df['Section'].str.replace('section_', '', regex=False)

# Generate LaTeX table
latex_table = counts_df.to_latex(
    index=False,
    columns=['Section', 'Low_Neg', 'Low_Neutral', 'Low_Pos', 'High_Neg', 'High_Neutral', 'High_Pos'],
    header=['Section', 'Low (-1)', 'Low (0)', 'Low (1)', 'High (-1)', 'High (0)', 'High (1)'],
    caption="Counts of Categories for Each Section in Low and High Complexity Data",
    label="tab:counts"
)

# Save LaTeX table to file
counts_tex_path = '/home/caro/DS_complexity/final_regression/results_with_controls/counts.tex'
with open(counts_tex_path, 'w') as f:
    f.write(latex_table)

print(f"LaTeX table of counts saved to {counts_tex_path}")


# Count the number of reports where all sections are neutral (0)
neutral_reports_low = low_complexity[sections].apply(lambda row: (row == 0).all(), axis=1).sum()
neutral_reports_high = high_complexity[sections].apply(lambda row: (row == 0).all(), axis=1).sum()

# Print the total count of such reports
print(f"Total number of reports where all sections are neutral: {neutral_reports_low + neutral_reports_high}")

#######################     REGRESSION      ############################################################################################
# Define the features and target variable
print('Columns')
print(low_complexity.columns)
#features = ['S&P500 Log Return', 'Total Assets', 'sic_1', 'sic_2', 'sic_3', 'sic_4', 'sic_5', 'sic_7', 'sic_8', 'sic_9'] # control variables
features = []
target = 'CAR'
features = features + [s + "_neg" for s in sections]
features = features + [s + "_pos" for s in sections]

features = [f for f in features if f not in ['section_15_neg', 'section_15_pos']]

print(f"Used Features: {features}")

# Calculate the correlation matrix for low complexity data
low_corr_matrix = low_complexity[features + [target]].corr()
 
# Plot the heatmap for low complexity data
'''plt.figure(figsize=(12, 8))
sns.heatmap(low_corr_matrix, annot=True, fmt=".2f", cmap="coolwarm", cbar=True)
plt.title("Correlation Heatmap (Low Complexity Data)")'''
#plt.show()

# Calculate the correlation matrix for high complexity data
high_corr_matrix = high_complexity[features + [target]].corr()

# Plot the heatmap for high complexity data
'''plt.figure(figsize=(12, 8))
sns.heatmap(high_corr_matrix, annot=True, fmt=".2f", cmap="coolwarm", cbar=True)
plt.title("Correlation Heatmap (High Complexity Data)")'''
#plt.show()







def perform_regression(data):
    
    filename = f'logs/test.txt'
    log_to_file(filename, f"Model: {FINAL_MODEL}, Time Window: {TIME_WINDOW}")
    log_to_file(filename, f"Low Complexity Data: {len(low_complexity)}, High Complexity Data: {len(high_complexity)}")
    log_to_file(filename, f"Complexity Threshold: {complexity_threshold}")

    X = data[features]
    y = data[target]
    
    X = sm.add_constant(X)

    model = sm.OLS(y, X).fit()
    print(model.summary())

    summary_df = model.summary2().tables[1].reset_index().rename(columns={'index': 'Variable'})
    summary_df[['Coef.', 'Std.Err.', '[0.025', '0.975]', 'P>|t|']] = summary_df[['Coef.', 'Std.Err.', '[0.025', '0.975]', 'P>|t|']].round(2)
    summary_df = summary_df.rename(columns={
        'Coef.': 'coef',
        'Std.Err.': 'SE',
        '[0.025': 'ci_lower',
        '0.975]': 'ci_upper',
        'P>|t|': 'p'
    })

    summary_df['coef'] = summary_df['coef'].map('{:.2f}'.format)

    def significance_stars(p):
        if p < 0.01:
            return '***'
        elif p < 0.05:
            return '**'
        elif p < 0.1:
            return '*'
        else:
            return ''

    summary_df['stars'] = summary_df['p'].apply(significance_stars)
    summary_df['coef_with_stars'] = summary_df['coef'].astype(str) + summary_df['stars']

    # Create a new DataFrame for LaTeX export
    adj_r_squared = model.rsquared_adj
    latex_dataframe = summary_df[['Variable', 'coef_with_stars', 'SE']].rename(columns={ #, 'ci'
        'coef_with_stars': 'Coef',
        'SE': 'SE'
    })
    latex_dataframe['Variable'] = latex_dataframe['Variable'].str.replace('section_', '', regex=False)
    #latex_dataframe['95% CI'] = latex_dataframe['95% CI'].map(lambda x: f"[{float(x.split(',')[0][1:]):.2f}, {float(x.split(',')[1][:-1]):.2f}]")
    latex_dataframe['SE'] = latex_dataframe['SE'].map(lambda x: f"{float(x):.2f}")
    #latex_dataframe['R2'] = adj_r_squared
    latex_dataframe.loc[len(latex_dataframe)] = ['adjusted $R^2$', f"{adj_r_squared:.2f}", '']
    # Export latex_dataframe as a LaTeX table
    latex_table = latex_dataframe.to_latex(index=False, escape=False, float_format="%.2f")
    output_path = '/home/caro/DS_complexity/final_regression/results_with_controls/summary_table.tex'
    #with open(output_path, 'w') as f:
    #    f.write(latex_table)
    log_to_file(filename, f"LaTeX table saved to {output_path}")



    summary_plot_df = summary_df[summary_df['Variable'] != 'const']

    plt.figure(figsize=(10, 6))
    sns.pointplot(
        data=summary_plot_df,
        y='Variable',
        x='coef',
        join=False,
        color='black'
    )
    for i, row in summary_plot_df.iterrows():
        plt.plot([row['ci_lower'], row['ci_upper']], [i, i], color='black', alpha=0.6)

    plt.axvline(x=0, linestyle='--', color='red', linewidth=1)
    plt.title("Coefficient Estimates with 95% Confidence Intervals")
    plt.xlabel("Coefficient Value")
    plt.ylabel("Section")
    plt.tight_layout()
    #plt.show()

    return latex_dataframe


'''    #cv_scores = cross_val_score(model, X, y, cv=kf, scoring='neg_mean_squared_error')
    model.fit(X, y)
    predictions = model.predict(X)
    rmse = np.sqrt(np.mean((y - predictions) ** 2))
    log_to_file(filename, f"RMSE: {rmse}")
    coefficients = dict(zip(features, model.fit(X, y).coef_))  # Fit the model and extract coefficients

    #print(f"Weights for sections: {dict(zip(sections, model.coef_))}")
    #cv_scores = np.sqrt(-cv_scores) # convert neg MSE to RMSE

    #weights = np.abs(weights) / np.sum(np.abs(weights))  # Normalize weights to sum to 1

    #return grid.best_estimator_, grid.cv_results_['mean_test_score']
    return rmse, coefficients'''


# Perform regression for low complexity data
df_low = perform_regression(low_complexity)
df_high = perform_regression(high_complexity)

# Combine low and high complexity dataframes for a single LaTeX table
df_low['Complexity'] = 'Low'
df_high['Complexity'] = 'High'
combined_dataframe = pd.concat([df_low, df_high], axis=0)
print(combined_dataframe)
# Save the combined_dataframe to a CSV file
# correct csv output path here
output_csv_path = f'/home/caro/DS_complexity/final_regression/results_without_controls/{FINAL_MODEL}_{TIME_WINDOW}.csv'
combined_dataframe.to_csv(output_csv_path, index=False)
print(f"Combined dataframe saved to {output_csv_path}")

latex_lines = [
    r'\begin{tabular}{l c c}',
    r'\toprule',
    r'      & \multicolumn{2}{c}{\textbf{Complexity}} \\',
    r'\cmidrule(lr){2-3}'
    r'\textbf{Item} & \textbf{Low} & \textbf{High} \\',
    r'\midrule'
]
tabular = 'tabular'

for i in range(len(df_low)):
    var = df_low.iloc[i]['Variable']
    
    # Low complexity values
    coef_l = df_low.iloc[i]['Coef']
    se_l = df_low.iloc[i]['SE']
    value_l = r"{\renewcommand{\arraystretch}{0.7}\begin{tabular}{@{}c@{}}" + str(coef_l) + r" \\ (" + str(se_l) + r") \end{tabular}}"
    
    # High complexity values
    coef_h = df_high.iloc[i]['Coef']
    se_h = df_high.iloc[i]['SE']
    value_h = r"{\renewcommand{\arraystretch}{0.7}\begin{tabular}{@{}c@{}}" + str(coef_h) + r" \\ (" + str(se_h) + r") \end{tabular}}"

    row = f"{var} & {value_l} & {value_h} \\\\"
    latex_lines.append(row)

latex_lines.append(r'\bottomrule')
latex_lines.append(r'\end{tabular}')

# Save to file
output_path = f'/home/caro/DS_complexity/final_regression/results_without_controls/combined_summary_table_{FINAL_MODEL}_{TIME_WINDOW}.tex'
#with open(output_path, 'w') as f:
#    f.write('\n'.join(latex_lines))

#print(f"LaTeX table saved to {output_path}")


'''# Extract and print R-squared values for both regressions
low_r2 = sm.OLS(low_complexity[target], sm.add_constant(low_complexity[features])).fit().rsquared
high_r2 = sm.OLS(high_complexity[target], sm.add_constant(high_complexity[features])).fit().rsquared

print(f"R-squared for Low Complexity Regression: {low_r2:.4f}")
print(f"R-squared for High Complexity Regression: {high_r2:.4f}")'''

'''
# Perform regression for high complexity data
high_rmse, high_coefficients = perform_regression(high_complexity)

# Print the results
print("Low Complexity Data:")
rounded_low_coefficients = {key: round(value, 2) for key, value in low_coefficients.items()}
#print(rounded_low_coefficients)
print(f"{np.mean(low_rmse):.2f}" + " & ".join(map(str, rounded_low_coefficients.values())))

print("\nHigh Complexity Data:")
rounded_high_coefficients = {key: round(value, 2) for key, value in high_coefficients.items()}
print(f"{np.mean(high_rmse):.2f}" + " & ".join(map(str, rounded_high_coefficients.values())))'''