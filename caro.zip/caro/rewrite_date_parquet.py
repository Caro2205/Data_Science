import pandas as pd
from datetime import datetime

df = pd.read_parquet('/home/caro/DS_complexity/data/final_data.parquet')

def reformat_date(date_str):
    date_obj = datetime.strptime(date_str, '%Y-%m-%d')
    return date_obj.strftime('%Y%m%d')

df['Filing Date'] = df['Filing Date'].apply(reformat_date)

df.to_parquet('/home/caro/DS_complexity/data/final_data_reformatted.parquet', index=False)
