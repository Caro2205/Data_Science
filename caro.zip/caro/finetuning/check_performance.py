from transformers import AutoTokenizer, AutoModelForSequenceClassification, ModernBertForSequenceClassification
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
import pyarrow as pa
import tqdm
import torch
import argparse
import json


# original code from steven, I just adapted for testing the models on financial phrase bank dataset


def get_sentiment_df(config, model_dir):
    #model_dir = Path(config['model_dir'])
    
    #tokenizer = AutoTokenizer.from_pretrained(config['tokenizer'])
    #model = AutoModelForSequenceClassification.from_pretrained(model_dir)
    model = ModernBertForSequenceClassification.from_pretrained("answerdotai/ModernBERT-base",num_labels=3)
    tokenizer = AutoTokenizer.from_pretrained("answerdotai/ModernBERT-base") # ,max_length=8912
    #tokenizer = AutoTokenizer.from_pretrained("ProsusAI/finbert")

    model.to("cuda")
    model.eval()

    data_path = Path('/home/caro/DS_complexity/finetuning/financial_phrases_all_updated.txt')



    data = pd.read_csv(data_path, sep="\t", header=None, names=["text", "split", "sentiment"])

    def sentiment(batch_texts):
        with torch.no_grad():
            inputs = tokenizer(batch_texts, return_tensors="pt", padding=True, truncation=True, 
                               max_length=8192).to("cuda")  
            outputs = model(**inputs)
            return torch.argmax(outputs.logits, dim=1).tolist()

    results = []

    for split in ["train", "test"]:
        split_data = data[data["split"] == split]
        texts = split_data["text"].tolist()
        true_sentiments = split_data["sentiment"].tolist()

        predicted_sentiments = []
        for i in tqdm.tqdm(range(0, len(texts), 8), desc=f"Processing {split} split"):
            batch_texts = texts[i:i+8]
            predicted_sentiments.extend(sentiment(batch_texts))

        results.append(pd.DataFrame({
            "text": texts,
            "true_sentiment": true_sentiments,
            "predicted_sentiment": predicted_sentiments,
            "split": [split] * len(texts)
        }))

    final_df = pd.concat(results, ignore_index=True)
    final_df.to_csv(output_path, index=False)

    test_data = results[1]  
    accuracy = (test_data["true_sentiment"] == test_data["predicted_sentiment"]).mean()
    with open(output_path_accuracy, "w") as f:
        f.write(f"Test Accuracy: {accuracy}\n")
    



model_dir = '/home/caro/DS_complexity/finetuning/modernbert-sentiment-sweep/7iwzoz7v' + '/'
#model_dir = f'/home/caro/DS_complexity/finetuning/{model}-sentiment-sweep/'
config_path = f'{model_dir}config.json'
output_path = f'{model_dir}sentiment_results.csv'
output_path_accuracy = f'{model_dir}sentiment_accuracy.txt'
config = json.load(open(config_path))
get_sentiment_df(config, model_dir)
