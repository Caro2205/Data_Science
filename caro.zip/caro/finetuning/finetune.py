import numpy as np
import pandas as pd 
from transformers import BertTokenizer, Trainer, BertForSequenceClassification, TrainingArguments, AutoTokenizer, AutoModelForSequenceClassification, ModernBertForSequenceClassification
from datasets import Dataset
import torch
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import wandb
import datetime
import os

# tested in transformers==4.18.0, pytorch==1.7.1 
import torch
import transformers
import json
torch.__version__, transformers.__version__

torch.cuda.is_available()

model = 'modernbert'  # Options: 'film', 'film_sec', 'modernbert', 'finbert'

folder = f'{model}-sentiment-sweep/'
os.makedirs(folder, exist_ok=True)

# HERE
sweep_configuration = {
    "method": "bayes",
    "name": "sweep",
    "metric": {"goal": "maximize", "name": "val_acc"},
    "parameters": {
        "lr": {"values": [5e-03, 8e-3, 1e-4, 3e-04, 5e-4, 8e-4, 1e-5]}, # 8e-05, 5e-05 
        "wd": {"values": [1e-3, 1e-4, 1e-5, 1e-6, 3e-6, 5e-6]}, #1e-6, 1e-5, 5e-6
        "epochs": {"values": [3, 5, 10]}, # , 2, 3, 5, 10
        "batch_size": {"values": [1]},
        "grad_accum_steps": {"values": [8, 16, 32, 64, 128]} # 16, 32, 64
    }
}
# Finbert
'''sweep_configuration = {
    "method": "grid",
    "name": "sweep",
    "metric": {"goal": "maximize", "name": "val_acc"},
    "parameters": {
        "wd": {"values": [1e-07]}, #also try out these: , 1e-09
        "batch_size": {"values": [1]},
        "lr": {"values": [2e-05]},
        "epochs": {"values": [5]}
#MINI batch size 64, max length 64, 6 epochs, dropout 0.1
    }
}'''
# FiLM
#sweep_configuration = {
#    "method": "grid",
#    "name": "sweep",
#    "metric": {"goal": "maximize", "name": "val_acc"},
#    "parameters": {
#        "wd": {"values": [2e-05]}, #{1e-3, 1e-4, 1e-5, 2e-5, 3e-5, 4e-5, 5e-5}
#        "batch_size": {"values": [1]},
#        "lr": {"values": [2e-05]}
#batch size 16, 32, 64, max length 128, 20 epochs, weight decay not mentioned
#    }
#}
sweep_id = wandb.sweep(sweep=sweep_configuration, project="folder")

df = pd.read_csv('/home/caro/DS_complexity/finetuning/financial_phrases_all_updated.txt', delimiter='\t', names=['sentence', 'label', 'sentiment'])
df.head()

print(df['label'].value_counts())
df_train = df[df['label'] == 'train']
df_test = df[df['label'] == 'test']
df_train, df_val = train_test_split(df_train, stratify=df_train['sentiment'], test_size=0.1, random_state=42)

logs_folder = f'{folder}/logs'
os.makedirs(logs_folder, exist_ok=True)

def log_to_file(filename, message):
    safe_filename = filename.replace(":", "-").replace(" ", "_")
    with open(f'{safe_filename}', "a") as file: 
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        file.write(f"[{timestamp}] {message}\n")
    #print(f"Logged to {safe_filename}: {message}")

############ set model specifications here
# HERE
max_length = 512 if model in ['film', 'film_sec', 'finbert'] else 8192
# Load tokenizer configuration from model_configs folder
config_path = f'model_configs/{model}.json'
with open(config_path, 'r') as config_file:
        small_config = json.load(config_file)

hugging_face_model = small_config['model']
hugging_face_tokenizer = small_config['tokenizer']

model = ModernBertForSequenceClassification.from_pretrained(hugging_face_model,num_labels=3)
tokenizer = AutoTokenizer.from_pretrained(hugging_face_tokenizer, max_length=max_length)
tokenizer.model_max_length = max_length 

#print(tokenizer.model_max_length)
#print(model.config)


dataset_train = Dataset.from_pandas(df_train)
dataset_val = Dataset.from_pandas(df_val)
dataset_test = Dataset.from_pandas(df_test)

dataset_train = dataset_train.map(lambda e: tokenizer(e['sentence'], truncation=True, max_length=max_length), batched=True)
dataset_val = dataset_val.map(lambda e: tokenizer(e['sentence'], truncation=True, max_length=max_length), batched=True)
dataset_test = dataset_test.map(lambda e: tokenizer(e['sentence'], truncation=True, max_length=max_length), batched=True)

dataset_train = dataset_train.remove_columns(['label']).rename_column('sentiment', 'label')
dataset_val = dataset_val.remove_columns(['label']).rename_column('sentiment', 'label')
dataset_test = dataset_test.remove_columns(['label']).rename_column('sentiment', 'label')


dataset_train.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label']) #dataset_train.set_format(type='torch', columns=['input_ids', 'token_type_ids', 'attention_mask', 'label'])
dataset_val.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])
dataset_test.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])

def compute_metrics(eval_pred):
    predictions, labels = eval_pred
    predictions = np.argmax(predictions, axis=1)
    return {'accuracy' : accuracy_score(predictions, labels)}



def train():
        import torch, gc

        gc.collect()
        torch.cuda.empty_cache()
        run = wandb.init()
        args = TrainingArguments(
        output_dir = 'temp/',
        evaluation_strategy = 'epoch',
        save_strategy = 'epoch',
        learning_rate=wandb.config.lr,
        per_device_train_batch_size=wandb.config.batch_size,
        per_device_eval_batch_size=wandb.config.batch_size,
        num_train_epochs=wandb.config.epochs,
        weight_decay=wandb.config.wd,
        load_best_model_at_end=True,
        metric_for_best_model='accuracy',
        gradient_accumulation_steps=wandb.config.grad_accum_steps,
        )
        log_filename = f'{folder}logs/{run.id}.log'
        log_to_file(log_filename, f"Batch size: {wandb.config.batch_size}")
        log_to_file(log_filename, f"Learning rate: {wandb.config.lr}")
        log_to_file(log_filename, f"Weight decay: {wandb.config.wd}")
        log_to_file(log_filename, f"Epochs: {wandb.config.epochs}")
        log_to_file(log_filename, f"Model: {model}")
        log_to_file(log_filename, str(args))
        # Save training arguments
        args_dict = args.to_dict()
        with open(f'{folder}logs/{run.id}_training_args.json', 'w') as f:
                args_dict['tokenizer_max_length'] = max_length 
                json.dump(args_dict, f, indent=4)

        trainer = Trainer(
                model=model,                        
                args=args,                 
                train_dataset=dataset_train,         
                eval_dataset=dataset_val,           
                compute_metrics=compute_metrics
        )
        trainer.train()
        metrics = trainer.evaluate()
        wandb.log(metrics)
        os.makedirs(f'{folder}/{run.id}', exist_ok=True)
        trainer.save_model(f'{folder}/{run.id}')
        #return metrics


#trainer.train()   

#model.eval()
#trainer.predict(dataset_test).metrics

#trainer.save_model(folder)

wandb.agent(sweep_id, function=train, count=50)  # Set count to the maximum number of runs