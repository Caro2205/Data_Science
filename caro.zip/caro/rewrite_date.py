import pandas as pd
from datetime import datetime

df = pd.read_csv('/home/caro/DS_complexity/complexity_scores_new.csv')

def reformat_date(date_str):
    date_obj = datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%S%z')
    return date_obj.strftime('%Y%m%d')

df['filing_date'] = df['filing_date'].apply(reformat_date)

df.to_csv('/home/caro/DS_complexity/complexity_scores_new_reformatted.csv', index=False)